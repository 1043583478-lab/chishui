"""
赤水 · Chishui 推理引擎后端

FastAPI 服务，负责：
1. 注入赤水 system prompt（8 算符 + 5 阶段对话 + 教员口吻）
2. 管理会话状态和对话历史
3. 代理请求到 LLM API（DeepSeek / OpenAI / Anthropic）
"""

import json
import os
import time
import uuid
from contextlib import asynccontextmanager
from typing import Optional

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from prompt import build_system_prompt

# ============================================================
# 配置
# ============================================================

# 从环境变量读取服务器端 API Key（部署时设置）
SERVER_API_KEY = os.getenv("CHISHUI_API_KEY", "")
SERVER_PROVIDER = os.getenv("CHISHUI_PROVIDER", "deepseek")  # deepseek / openai / anthropic
SERVER_ENDPOINT = os.getenv("CHISHUI_ENDPOINT", "")  # 自定义端点

# 各提供商的默认配置
PROVIDERS = {
    "deepseek": {
        "name": "DeepSeek",
        "model": "deepseek-chat",
        "url": "https://api.deepseek.com/v1/chat/completions",
        "api_type": "openai",
    },
    "openai": {
        "name": "OpenAI",
        "model": "gpt-4o",
        "url": "https://api.openai.com/v1/chat/completions",
        "api_type": "openai",
    },
    "anthropic": {
        "name": "Anthropic",
        "model": "claude-sonnet-4-6",
        "url": "https://api.anthropic.com/v1/messages",
        "api_type": "anthropic",
    },
}

# ============================================================
# 会话管理（内存，重启清空）
# ============================================================

SESSION_TIMEOUT = 3600  # 1 小时过期

sessions: dict[str, dict] = {}


def _cleanup_expired():
    """清理过期会话。"""
    now = time.time()
    expired = [sid for sid, s in sessions.items() if now - s["last_active"] > SESSION_TIMEOUT]
    for sid in expired:
        del sessions[sid]


def get_or_create_session(session_id: Optional[str]) -> tuple[str, dict]:
    """获取或创建会话。"""
    _cleanup_expired()
    if session_id and session_id in sessions:
        s = sessions[session_id]
        s["last_active"] = time.time()
        return session_id, s
    new_id = str(uuid.uuid4())
    s = {
        "id": new_id,
        "created_at": time.time(),
        "last_active": time.time(),
        "messages": [
            {"role": "system", "content": build_system_prompt()}
        ],
        "stage": "investigate",  # 当前阶段
        "operator_index": 0,      # 当前算符序号
        "question_count": 0,      # 本轮已提问数
    }
    sessions[new_id] = s
    return new_id, s


# ============================================================
# LLM 调用
# ============================================================

async def _call_openai_api(messages: list[dict], api_key: str, provider_config: dict) -> str:
    """调用 OpenAI 兼容 API（DeepSeek / OpenAI / 自定义端点）。"""
    url = provider_config["url"]
    if SERVER_ENDPOINT:
        url = SERVER_ENDPOINT

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    # 过滤掉 system message 中的空 content（某些 API 不接受）
    clean_messages = [m for m in messages if m.get("content")]

    body = {
        "model": provider_config["model"],
        "messages": clean_messages,
        "temperature": 0.7,
        "max_tokens": 4096,
    }

    async with httpx.AsyncClient(timeout=120.0) as client:
        resp = await client.post(url, headers=headers, json=body)
        if resp.status_code != 200:
            raise HTTPException(status_code=502, detail=f"API 错误: {resp.status_code} {resp.text[:500]}")
        data = resp.json()
        return data["choices"][0]["message"]["content"]


async def _call_anthropic_api(messages: list[dict], api_key: str, provider_config: dict) -> str:
    """调用 Anthropic API。"""
    # 分离 system prompt 和对话消息
    system_content = ""
    chat_messages = []
    for m in messages:
        if m["role"] == "system":
            system_content = m["content"]
        else:
            chat_messages.append(m)

    body = {
        "model": provider_config["model"],
        "max_tokens": 4096,
        "system": system_content,
        "messages": [
            {"role": m["role"], "content": m["content"]}
            for m in chat_messages
        ],
    }

    headers = {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json",
    }

    async with httpx.AsyncClient(timeout=120.0) as client:
        resp = await client.post(provider_config["url"], headers=headers, json=body)
        if resp.status_code != 200:
            raise HTTPException(status_code=502, detail=f"API 错误: {resp.status_code} {resp.text[:500]}")
        data = resp.json()
        return data["content"][0]["text"]


async def call_llm(messages: list[dict], api_key: str, provider: str = "deepseek") -> str:
    """统一 LLM 调用入口。"""
    if provider not in PROVIDERS:
        raise HTTPException(status_code=400, detail=f"不支持的提供商: {provider}")

    config = PROVIDERS[provider]

    if config["api_type"] == "anthropic":
        return await _call_anthropic_api(messages, api_key, config)
    else:
        return await _call_openai_api(messages, api_key, config)


# ============================================================
# FastAPI 应用
# ============================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期。"""
    print(f"🔥 赤水推理引擎启动")
    print(f"   Provider: {SERVER_PROVIDER}")
    print(f"   Server Key: {'已配置' if SERVER_API_KEY else '未配置（需客户端传入）'}")
    yield
    print("赤水引擎关闭")

app = FastAPI(title="赤水 Chishui 推理引擎", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================
# API 模型
# ============================================================

class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None
    api_key: Optional[str] = None  # 客户端可传入自己的 Key
    provider: Optional[str] = "deepseek"
    system_extra: Optional[str] = None  # 客户端注入的额外系统指令（如结束标记）


class ChatResponse(BaseModel):
    reply: str
    session_id: str
    stage: str


class SessionInfo(BaseModel):
    session_id: str
    stage: str
    message_count: int


# ============================================================
# API 端点
# ============================================================

@app.get("/api/health")
async def health():
    return {"status": "ok", "provider": SERVER_PROVIDER}


@app.post("/api/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    """核心对话端点。"""
    # 确定 API Key：客户端传入 > 服务器配置
    api_key = req.api_key or SERVER_API_KEY
    if not api_key:
        raise HTTPException(status_code=400, detail="请先配置 API Key")

    provider = req.provider or SERVER_PROVIDER

    # 获取或创建会话
    session_id, session = get_or_create_session(req.session_id)

    # 存储额外的系统指令（如对话结束标记指令），每次请求可更新
    if req.system_extra:
        session["system_extra"] = req.system_extra

    # 幂等重建系统消息：base prompt + 已存储的 system_extra
    base_system = build_system_prompt()
    extra = session.get("system_extra", "")
    system_content = base_system + ("\n\n" + extra if extra else "")
    session["messages"][0] = {"role": "system", "content": system_content}

    # 添加用户消息
    session["messages"].append({"role": "user", "content": req.message})

    # 调用 LLM
    try:
        reply = await call_llm(session["messages"], api_key, provider)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"LLM 调用失败: {str(e)}")

    # 添加助手回复到历史
    session["messages"].append({"role": "assistant", "content": reply})

    # 简单阶段推断（基于关键词）
    stage = _infer_stage(reply)

    return ChatResponse(
        reply=reply,
        session_id=session_id,
        stage=stage,
    )


@app.post("/api/session/reset")
async def reset_session(session_id: Optional[str] = None):
    """重置会话，清除上下文。"""
    if session_id and session_id in sessions:
        sessions[session_id]["messages"] = [
            {"role": "system", "content": build_system_prompt()}
        ]
        sessions[session_id]["stage"] = "investigate"
        sessions[session_id]["question_count"] = 0
        return {"session_id": session_id, "status": "reset"}
    return {"session_id": None, "status": "not_found"}


@app.get("/api/session/{session_id}", response_model=SessionInfo)
async def get_session(session_id: str):
    """获取会话信息。"""
    if session_id not in sessions:
        raise HTTPException(status_code=404, detail="会话不存在")
    s = sessions[session_id]
    return SessionInfo(
        session_id=session_id,
        stage=s.get("stage", "investigate"),
        message_count=sum(1 for m in s["messages"] if m["role"] != "system"),
    )


def _infer_stage(reply: str) -> str:
    """从回复内容推断当前对话阶段。"""
    if any(kw in reply for kw in ["矛盾重构", "真正的矛盾", "现象", "错位", "主要矛盾是"]):
        return "contradict"
    if any(kw in reply for kw in ["战略分析", "持久战", "阶段判断", "防御", "相持", "反攻"]):
        return "analyze"
    if any(kw in reply for kw in ["反向假设", "极端测试", "换位追问", "追问深化", "如果"]):
        return "deepen"
    if any(kw in reply for kw in ["辩证收尾", "前途是光明的", "道路是曲折的"]):
        return "close"
    return "investigate"


# ============================================================
# 入口
# ============================================================

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", "8100"))
    uvicorn.run(app, host="0.0.0.0", port=port)
