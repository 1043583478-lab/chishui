# 赤水 Chishui · 部署指南

## 项目类型

纯静态单页应用（SPA），**不需要后端服务器**。浏览器直接调用 LLM API。

---

## 部署前准备

### 1. 配置 API Key

**推荐方式**：部署后用户在页面右下角 🔑 按钮自行填入 Key，Key 保存在浏览器 localStorage，不会随文件包一起分发。

**不推荐**：修改 `api_config.json`（仅在本地测试时使用，**不要部署到公网**）：

```json
{
  "k": "sk-your-api-key",
  "p": "deepseek",
  "c": ""
}
```

| 参数 | 说明 |
|------|------|
| `k` | API Key |
| `p` | 提供商：`anthropic` / `deepseek` / `openai` / `custom` |
| `c` | 自定义端点 URL（仅 `custom` 时需要） |

### 2. 确认文件结构

Docker 部署只需要这 2 个文件（api_config.json 已从 Docker 镜像中移除）：

```
├── chishui-builtin.html   # 主应用
├── mao-quotes.js          # 毛选语录
```

手动部署时可选添加 `api_config.json`（仅本地使用，**不要部署到公网**）。

---

## 部署方式

### 方式一：Docker（推荐）

```bash
# 在 chishuiV2 目录下
docker compose up -d

# 访问 http://your-server-ip:8080
```

自定义端口：编辑 `docker-compose.yml` 中的 `"8080:80"`，改为 `"80:80"` 或其他。

### 方式二：Nginx 直接部署

```bash
# 1. 上传文件到服务器（不要上传 api_config.json）
scp chishui-builtin.html mao-quotes.js user@server:/var/www/chishui/

# 2. 服务器上安装 Nginx
sudo apt update && sudo apt install nginx -y

# 3. 创建站点配置
sudo tee /etc/nginx/sites-available/chishui << 'EOF'
server {
    listen 80;
    server_name _;
    root /var/www/chishui;
    index chishui-builtin.html;

    location = / {
        try_files /chishui-builtin.html =404;
    }

    location ~* \.(js|json)$ {
        expires 1d;
    }
}
EOF

# 4. 启用站点
sudo ln -s /etc/nginx/sites-available/chishui /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default  # 移除默认站点（可选）
sudo nginx -t && sudo systemctl reload nginx
```

### 方式三：Caddy（自动 HTTPS）

```bash
# 上传文件（不要上传 api_config.json）
scp chishui-builtin.html mao-quotes.js user@server:/var/www/chishui/

# Caddyfile
echo '
your-domain.com {
    root * /var/www/chishui
    try_files {path} /chishui-builtin.html
    file_server
}
' | sudo tee /etc/caddy/Caddyfile

sudo systemctl reload caddy
```

### 方式四：Vercel（免费）

```bash
npm i -g vercel
cd chishuiV2
vercel --prod
```

需要 `vercel.json`：
```json
{
  "rewrites": [
    { "source": "/", "destination": "/chishui-builtin.html" }
  ]
}
```

### 方式五：本地快速测试

```bash
cd chishuiV2
python3 -m http.server 8080
# 打开 http://localhost:8080/chishui-builtin.html
```

---

## 安全提醒

- `api_config.json` 中的 Key 对所有访问者可见，仅适合个人使用
- 用户通过页面上"保存"按钮存入的 Key，存储于浏览器 localStorage（键名 `cs2`），**明文存储**。若页面存在 XSS 漏洞，攻击者可通过 `localStorage.getItem('cs2')` 窃取 Key。请勿在不受信任的域名上使用同一 Key
- `BUILTIN_KEY` 变量（`chishui-builtin.html:752`）会硬编码进 HTML 源码，部署到公网时绝对不要填入真实 Key
- 如需多用户共享，建议搭建后端代理层，将 API Key 存于服务端
- 部署到公网时建议启用 HTTPS（Caddy 可自动获取证书）
- Nginx 已配置基础安全头（`X-Content-Type-Options`、`X-Frame-Options`）。如果你通过其他方式部署（Python http.server / Vercel），这些头不会被添加

---

## Python 组件说明

`kernel/` 和 `operators/` 是本地 Python 推理库，不需要部署到服务器。它们是给 Claude Code 等 LLM 客户端本地使用的推理框架。
